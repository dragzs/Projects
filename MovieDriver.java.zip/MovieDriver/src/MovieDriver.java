import java.util.Scanner;

public class MovieDriver {
	
	static Scanner movieDetails = new Scanner(System.in);
	
	public static void movieLoop() {
		
		String movieName;
		String movieRating;
		int movieTickets;
		
		System.out.println("Enter the name of the movie: ");
		movieName = movieDetails.nextLine();
		
		System.out.println("Enter the rating of the movie: ");
		movieRating = movieDetails.nextLine();
		
		System.out.println("How many tickets were sold for this movie: ");
		movieTickets = movieDetails.nextInt();
		
		
		System.out.println("Would you like to enter info for another movie? y/n");
		String x = movieDetails.next();
		
		movieDetails.nextLine();

		if (x.equals("y")) {
			
			movieLoop();
			
		}
		else {
		System.out.println("Goodbye");
		
		

		}
		
	}
	
	public static void main(String[] args) {
		
		
		movieLoop();
				
		

	}
}
